import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../api/generated/hr_api.dart';
import '../core/l10n/locale_controller.dart';
import '../core/l10n/strings.dart';
import '../core/session/session_controller.dart';
import '../core/theme/tokens.dart';
import '../core/widgets/hr_logo.dart';
import '../features/notifications/unread_count.dart';

class NavItem {
  const NavItem(this.path, this.icon, this.label, {this.operation, this.anyOf = const <String>[], this.admin = false});
  final String path;
  final IconData icon;
  final String Function(S s) label;

  /// Shown only when the user holds this operation's x-permission.
  final String? operation;

  /// Alternatively shown when any of these operations is granted.
  final List<String> anyOf;

  /// Listed under the administration section.
  final bool admin;

  bool visibleFor(Session session) {
    if (operation == null && anyOf.isEmpty) return true;
    if (operation != null && session.can(operation!)) return true;
    return anyOf.any(session.can);
  }
}

final navItems = <NavItem>[
  NavItem('/', Icons.space_dashboard_outlined, (s) => s.home),
  NavItem('/inbox', Icons.pending_actions_outlined, (s) => s.inbox, operation: HrOps.Request_GetInbox),
  NavItem('/requests', Icons.assignment_outlined, (s) => s.myRequests, operation: HrOps.Request_GetMy),
  NavItem('/leaves', Icons.beach_access_outlined, (s) => s.leaves, operation: HrOps.LeaveBalance_GetMy),
  NavItem('/attendance', Icons.schedule_outlined, (s) => s.attendance, operation: HrOps.Attendance_GetMy),
  NavItem('/notifications', Icons.notifications_none, (s) => s.notifications, operation: HrOps.Notification_List),
  NavItem('/memos', Icons.description_outlined, (s) => s.t('المطالعات', 'Memos'), anyOf: [HrOps.Memo_GetMy, HrOps.Memo_GetInbox]),
  NavItem('/incidents', Icons.build_circle_outlined, (s) => s.t('بلاغات الأعطال', 'Fault incidents'), anyOf: [HrOps.Incident_GetMy, HrOps.Incident_GetInbox]),
  NavItem('/complaints', Icons.shield_outlined, (s) => s.t('الشكاوى', 'Complaints'), anyOf: [HrOps.Complaint_GetMyList, HrOps.Complaint_GetAssignedList]),
  NavItem('/circulars', Icons.campaign_outlined, (s) => s.t('التعاميم', 'Circulars'), operation: HrOps.Circular_GetReceivedList),
  NavItem('/evaluations', Icons.rate_review_outlined, (s) => s.t('التقييمات', 'Evaluations'),
      anyOf: [HrOps.Evaluation_GetMyList, HrOps.Evaluation_GetTeamList, HrOps.Evaluation_GetHrList]),
  NavItem('/custody', Icons.inventory_2_outlined, (s) => s.t('العهد', 'Custody'), anyOf: [HrOps.Custody_GetMy, HrOps.Custody_GetTeam, HrOps.Custody_GetList]),
  NavItem('/payslips', Icons.receipt_long_outlined, (s) => s.t('قسائم الراتب', 'Payslips'), operation: HrOps.Payslip_GetMyList),
  NavItem('/contracts', Icons.description_outlined, (s) => s.t('العقود', 'Contracts'), anyOf: [HrOps.Contract_GetMyList, HrOps.Contract_List]),
  NavItem('/warnings', Icons.report_outlined, (s) => s.t('الإنذارات', 'Warnings'),
      anyOf: [HrOps.Warning_GetMyList, HrOps.Warning_GetRecommendedByMe, HrOps.Warning_List, HrOps.Warning_GetObjections]),
  NavItem('/appreciation', Icons.workspace_premium_outlined, (s) => s.t('كتب الشكر', 'Appreciation letters'),
      anyOf: [HrOps.AppreciationLetter_GetMyList, HrOps.AppreciationLetter_List]),
  NavItem('/holidays', Icons.event_note_outlined, (s) => s.t('العطل', 'Holidays'), operation: HrOps.Holiday_List),
  NavItem('/delegations', Icons.swap_horizontal_circle_outlined, (s) => s.t('التفويض', 'Delegations'), operation: HrOps.Delegation_GetMy),
  NavItem('/profile', Icons.person_outline, (s) => s.profile),
  NavItem('/team', Icons.groups_2_outlined, (s) => s.t('فريقي', 'My team'), operation: HrOps.Manager_GetMyTeam, admin: true),
  NavItem('/team-calendar', Icons.calendar_month_outlined, (s) => s.t('تقويم إجازات الفريق', 'Team leave calendar'), operation: HrOps.LeaveCalendar_GetTeam, admin: true),
  NavItem('/attendance-admin', Icons.fact_check_outlined, (s) => s.t('حضور الموظفين', 'Employee attendance'), operation: HrOps.Attendance_GetByEmployee, admin: true),
  NavItem('/leave-balances', Icons.account_balance_wallet_outlined, (s) => s.t('أرصدة الإجازات', 'Leave balances'), operation: HrOps.LeaveBalance_SetEntitlement, admin: true),
  NavItem('/employees', Icons.badge_outlined, (s) => s.t('الموظفون', 'Employees'), operation: HrOps.Employee_List, admin: true),
  NavItem('/departments', Icons.apartment_outlined, (s) => s.t('الأقسام', 'Departments'), operation: HrOps.Department_List, admin: true),
  NavItem('/accounts', Icons.manage_accounts_outlined, (s) => s.t('الحسابات', 'Accounts'), operation: HrOps.UserAccount_List, admin: true),
  NavItem('/shifts', Icons.schedule_outlined, (s) => s.t('قوالب الدوام', 'Shift templates'), operation: HrOps.WorkShift_List, admin: true),
  NavItem('/devices', Icons.fingerprint, (s) => s.t('أجهزة البصمة', 'Attendance devices'), operation: HrOps.AttendanceDevice_List, admin: true),
  NavItem('/attendance-import', Icons.upload_file_outlined, (s) => s.t('استيراد الحضور', 'Attendance import'), operation: HrOps.AttendanceImport_List, admin: true),
  NavItem('/attendance-settings', Icons.tune, (s) => s.t('إعدادات الحضور', 'Attendance settings'), operation: HrOps.AttendanceSettings_Update, admin: true),
  NavItem('/leave-types', Icons.category_outlined, (s) => s.t('أنواع الإجازات', 'Leave types'), operation: HrOps.OtherLeaveType_List, admin: true),
  NavItem('/complaint-handlers', Icons.gavel_outlined, (s) => s.t('معالجو الشكاوى', 'Complaint handlers'), operation: HrOps.ComplaintHandler_GetList, admin: true),
  NavItem('/roles', Icons.admin_panel_settings_outlined, (s) => s.t('الأدوار والصلاحيات', 'Roles and permissions'), operation: HrOps.Role_List, admin: true),
  NavItem('/store', Icons.warehouse_outlined, (s) => s.t('المخزن', 'Store'), anyOf: [HrOps.StockIssue_GetList, HrOps.Item_GetList], admin: true),
  NavItem('/finance', Icons.account_balance_outlined, (s) => s.t('المالية', 'Finance'), anyOf: [HrOps.PayrollRun_List, HrOps.SalaryProfile_List], admin: true),
  NavItem('/department-reports', Icons.summarize_outlined, (s) => s.t('التقارير الشهرية', 'Monthly reports'), operation: HrOps.DepartmentReport_GetList, admin: true),
  NavItem('/evaluation-admin', Icons.checklist, (s) => s.t('معايير التقييم', 'Evaluation criteria'), operation: HrOps.EvaluationCriterion_GetList, admin: true),
  NavItem('/request-types', Icons.list_alt_outlined, (s) => s.t('أنواع الطلبات', 'Request types'), operation: HrOps.RequestType_GetAdminList, admin: true),
  NavItem('/reports', Icons.bar_chart_outlined, (s) => s.t('التقارير', 'Reports'),
      anyOf: [HrOps.Report_GetTeamAttendance, HrOps.Report_GetReviewDashboard, HrOps.Report_GetHrAttendance], admin: true),
  NavItem('/system-settings', Icons.settings_suggest_outlined, (s) => s.t('إعدادات النظام', 'System settings'), operation: HrOps.SystemSettings_ListSections, admin: true),
  NavItem('/audit-log', Icons.history_edu_outlined, (s) => s.t('سجل التدقيق', 'Audit log'), operation: HrOps.AuditLog_List, admin: true),
];

/// Desktop ≥1280: full sidebar. Tablet 768–1279: collapsed rail. Mobile <768: drawer.
class AppShell extends ConsumerWidget {
  const AppShell({super.key, required this.child, required this.location});
  final Widget child;
  final String location;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(sessionProvider);
    final items = navItems.where((i) => i.visibleFor(session)).toList();
    final width = MediaQuery.sizeOf(context).width;
    final selected = _selectedIndex(items);

    if (width < 768) {
      return Scaffold(
        appBar: AppBar(
          title: const HrLogo(size: 28),
          actions: const [_TopActions()],
        ),
        drawer: Drawer(child: SafeArea(child: _SideNav(items: items, selected: selected, extended: true))),
        body: SafeArea(child: child),
      );
    }
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            _SideNav(items: items, selected: selected, extended: width >= 1280),
            Expanded(
              child: Column(children: [
                const Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(24, 12, 16, 0),
                  child: Row(children: [Spacer(), _TopActions()]),
                ),
                Expanded(child: child),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  int _selectedIndex(List<NavItem> items) {
    var best = 0;
    var bestLen = -1;
    for (var i = 0; i < items.length; i++) {
      final p = items[i].path;
      final match = p == '/' ? location == '/' : location.startsWith(p);
      if (match && p.length > bestLen) {
        best = i;
        bestLen = p.length;
      }
    }
    return best;
  }
}

class _SideNav extends ConsumerWidget {
  const _SideNav({required this.items, required this.selected, required this.extended});
  final List<NavItem> items;
  final int selected;
  final bool extended;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final c = context.hr;
    return Container(
      width: extended ? 264 : 76,
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      decoration: BoxDecoration(
        color: c.surface,
        borderRadius: BorderRadius.circular(HrColors.radiusCard),
        border: Border.all(color: c.border),
        boxShadow: c.shadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Center(child: HrLogo(size: 34, showWordmark: extended)),
          ),
          Expanded(
            child: ListView(padding: EdgeInsets.zero, children: [
              for (var i = 0; i < items.length; i++) ...[
                if (items[i].admin && (i == 0 || !items[i - 1].admin))
                  extended
                      ? Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(14, 14, 14, 6),
                          child: Text(s.t('الإدارة', 'Administration'),
                              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: c.textSecondary)),
                        )
                      : const Divider(height: 20),
                _NavTile(item: items[i], selected: i == selected, extended: extended, label: items[i].label(s)),
              ],
            ]),
          ),
          _NavTile(
            item: NavItem('', Icons.logout, (s) => s.signOut),
            selected: false,
            extended: extended,
            label: s.signOut,
            onTap: () => ref.read(sessionProvider.notifier).signOut(),
          ),
        ],
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  const _NavTile({required this.item, required this.selected, required this.extended, required this.label, this.onTap});
  final NavItem item;
  final bool selected;
  final bool extended;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.hr;
    final color = selected ? c.accent : c.textSecondary;
    final tile = Material(
      color: selected ? c.glow : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap ??
            () {
              Scaffold.maybeOf(context)?.closeDrawer();
              context.go(item.path);
            },
        child: Container(
          constraints: const BoxConstraints(minHeight: 44),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          child: Row(
            mainAxisAlignment: extended ? MainAxisAlignment.start : MainAxisAlignment.center,
            children: [
              Icon(item.icon, color: color, size: 22),
              if (extended) ...[
                const SizedBox(width: 14),
                Expanded(
                  child: Text(label,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: selected ? c.textPrimary : c.textSecondary,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w500)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: extended ? tile : Tooltip(message: label, child: tile),
    );
  }
}

class _TopActions extends ConsumerWidget {
  const _TopActions();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final session = ref.watch(sessionProvider);
    final unread = ref.watch(unreadCountProvider).valueOrNull ?? 0;
    final mode = ref.watch(themeModeProvider);
    final isAr = ref.watch(localeProvider).languageCode == 'ar';
    return Row(mainAxisSize: MainAxisSize.min, children: [
      IconButton(
        tooltip: s.language,
        onPressed: () => ref.read(localeProvider.notifier).set(isAr ? 'en' : 'ar'),
        icon: Text(isAr ? 'EN' : 'ع', style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
      IconButton(
        tooltip: s.theme,
        onPressed: () {
          final dark = mode == ThemeMode.dark ||
              (mode == ThemeMode.system && MediaQuery.platformBrightnessOf(context) == Brightness.dark);
          ref.read(themeModeProvider.notifier).set(dark ? ThemeMode.light : ThemeMode.dark);
        },
        icon: const Icon(Icons.contrast),
      ),
      if (session.can(HrOps.Notification_List))
        IconButton(
          tooltip: s.notifications,
          onPressed: () => context.go('/notifications'),
          icon: Badge(
            isLabelVisible: unread > 0,
            label: Text('$unread'),
            child: const Icon(Icons.notifications_none),
          ),
        ),
      Padding(
        padding: const EdgeInsetsDirectional.only(start: 4, end: 4),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => context.go('/profile'),
          child: CircleAvatar(
            radius: 18,
            backgroundColor: context.hr.glow,
            child: Text(
              (session.me?.displayName.isNotEmpty ?? false) ? session.me!.displayName.characters.first : '?',
              style: TextStyle(color: context.hr.accent, fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ),
    ]);
  }
}
